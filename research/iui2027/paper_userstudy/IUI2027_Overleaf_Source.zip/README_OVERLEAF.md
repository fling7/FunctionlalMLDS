# Overleaf package

1. Upload `IUI2027_Overleaf_Source.zip` as a new Overleaf project.
2. Set `main.tex` as the main document.
3. Use pdfLaTeX and the newest available TeX Live version (preferably TeX Live 2025).
4. Overleaf provides the ACM `acmart` class and runs BibTeX automatically.

The package is self-contained: all section files, BibTeX databases, TikZ sources, and raster images referenced by the manuscript are included. The source package is compiled in GitHub Actions before publication.
